<?
/**
 * Classe abstrata que implementa o protocolo FTP.
 * Esta classe deve ser extendida por cada aplica��o.
 *
 * criado em 08/04/2014 - bmy@trf4.gov.br
 * alterado em
 *
 * Observa��es:
 *
 */
abstract class InfraFTP implements InfraIProtocoloComunicacao {

  private $objConexao;
  
	public function __construct() {
	}

	/**
	 * Abrir conex�o com servidor FTP.
	 *
	 * @param boolean $bolConexaoSegura Parametro que define a utiliza��o de SSL ou n�o na conex�o.
	 * @param string $strIdConexao ID da conex�o
	 *
	 */
function abrirConexao($bolConexaoSegura, $strIdConexao) {
		try {
			if ($bolConexaoSegura) {
				if ($this->getPorta($strIdConexao) == 0) {
					$objConexao = ftp_ssl_connect($this->getServidor($strIdConexao));
				} else {
					$objConexao = ftp_ssl_connect($this->getServidor($strIdConexao), $this->getPorta($strIdConexao));
				}
			} else {
				if ($this->getPorta($strIdConexao) == 0) {
					$objConexao = ftp_connect($this->getServidor($strIdConexao));
				} else {
					$objConexao = ftp_connect($this->getServidor($strIdConexao), $this->getPorta($strIdConexao));
				}
			}

			if (!$objConexao) {
				throw new InfraException('N�o foi poss�vel abrir a conex�o FTP [(SSL: '.$bolConexaoSegura.') '.$this->getServidor($strIdConexao).':'.$this->getPorta($strIdConexao).'].');
			} else {
				$objValidacao = ftp_login($objConexao, $this->getUsuario($strIdConexao), $this->getSenha($strIdConexao));
				if (!$objValidacao) {
					throw new InfraException('Combina��o usu�rio/senha inv�lida [Conex�o '.$this->getServidor($strIdConexao).'].');
				} else {
					ftp_pasv($objConexao, true);
					$this->objConexao = $objConexao;
				}
			}
		} catch(Exception $e) {
			throw $e;
		}
	}

	function mostrarDiretorioLocal() {
		try {
			return ftp_pwd($this->objConexao);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function mostrarTamanhoArquivo($strArquivoRemoto) {
		try {
			return ftp_size($this->objConexao, $strArquivoRemoto);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function listarArquivos($strDiretorio) {
		try {
			return ftp_nlist($this->objConexao, $strDiretorio);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function listarArquivosDetalhes($strDiretorio) {
		try {
			return ftp_rawlist($this->objConexao, $strDiretorio);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function enviarArquivo($strArquivoLocal, $strArquivoRemoto) {
		try {
			return ftp_put($this->objConexao, $strArquivoRemoto, $strArquivoLocal, FTP_BINARY);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function receberArquivo($strArquivoLocal, $strArquivoRemoto) {
		try {
			return ftp_get($this->objConexao, $strArquivoLocal, $strArquivoRemoto, FTP_BINARY);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function renomearArquivo($strNomeArquivo, $strNovoNomeArquivo) {
		try {
			return ftp_rename($this->objConexao, $strNomeArquivo, $strNovoNomeArquivo);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function apagarArquivo($strArquivoRemoto) {
		try {
			return ftp_delete($this->objConexao, $strArquivoRemoto);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function criarDiretorio($strDiretorioRemoto) {
		try {
			return ftp_mkdir($this->objConexao, $strDiretorioRemoto);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function apagarDiretorio($strDiretorioRemoto) {
		try {
			return ftp_rmdir($this->objConexao, $strDiretorioRemoto);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function executarComando($strComando) {
		try {
			return ftp_exec($this->objConexao, $strComando);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function mostrarTipoSistemaRemoto() {
		try {
			return ftp_systype($this->objConexao);
		} catch(Exception $e) {
			throw $e;
		}
	}

	function fecharConexao() {
		try {
			return ftp_close($this->objConexao);
		} catch(Exception $e) {
			throw $e;
		}
	}
}
?>