<?
/**
 * TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
 *
 * 06/06/2006 - criado por MGA
 *
 * @package infra_php
 */

abstract class InfraBD {
  private $objInfraIBanco;
  private $arrAlias;
  private $arrCriteriosProcessados;
  private $arrGruposProcessados;
  private $strSql;

  public function __construct($objInfraIBanco){
    $this->objInfraIBanco = $objInfraIBanco;
  }

  protected function getObjInfraIBanco(){
    return $this->objInfraIBanco;
  }

  public function cadastrar($varObjInfraDTO, $bolRetornarSql=false) {
    try{
//      $m1 = memory_get_usage();
//      $t = InfraUtil::verificarTempoProcessamento();

      $bolMultiplo=is_array($varObjInfraDTO);
      if(is_array($varObjInfraDTO)){
        $numRegistros=count($varObjInfraDTO);
        if ($numRegistros==0) return null;
        $objInfraDTO=$varObjInfraDTO[0];
      } else {
        $numRegistros=1;
        $objInfraDTO=$varObjInfraDTO;
        $varObjInfraDTO=array($objInfraDTO);
      }

      $objInfraDTO->montarChaves();
      $strValues = '';
      $strSeparador = '';

      $arrPK = $objInfraDTO->getArrPK();

      $arrCampos = array();

      $strRetorno='';

      $bolExecIndividual=false;
      $bolPrimeiro=true;
      $bolOracle=$this->getObjInfraIBanco() instanceof InfraOracle;
      $strCampos='';
      $arrStrValues=array();
      foreach ($varObjInfraDTO as $objInfraDTO) {

        $arrAtributos = $objInfraDTO->getArrAtributos();
        $arrKeys = array_keys($arrAtributos);

        foreach($arrKeys as $key){
          $atributo=$arrAtributos[$key];
          if ($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null && $atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]===null){
            if (isset($arrPK[$key]) && $arrPK[$key] == InfraDTO::$TIPO_PK_SEQUENCIAL){

              //Obtem proxima sequencia para a tabela
              if ($bolPrimeiro) {
                $strCampos .= $strSeparador . $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];
              }
              $objInfraSequencia = new InfraSequencia($this->getObjInfraIBanco());
              $numProxSeq = $objInfraSequencia->obterProximaSequencia($objInfraDTO->getStrNomeTabela());
              $strValues .= $strSeparador.$numProxSeq;
              call_user_func(array($objInfraDTO,'set'.$atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO].$key),$numProxSeq);

            }else  if (isset($arrPK[$key]) && $arrPK[$key] == InfraDTO::$TIPO_PK_NATIVA){

              $numProxSeq = $this->getObjInfraIBanco()->getValorSequencia($objInfraDTO->getStrNomeSequenciaNativa());
              call_user_func(array($objInfraDTO,'set'.$atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO].$key),$numProxSeq);

              if ($bolPrimeiro) {
                $strCampos .= $strSeparador . $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];
              }
              $strValues .=  $strSeparador.$this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO],$numProxSeq);

            } else if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_SET){

              if($bolPrimeiro) {
                $strCampos .= $strSeparador . $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];
              }
              //  $strValues .=  $strSeparador.$this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO],call_user_func(array($objInfraDTO,'get'.$atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO].$key)));

              /* TRE-TO inicio - BIND clob - BANCO ORACLE*/
              if($bolOracle && $atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_STR) {
                $bolExecIndividual=true;
                $item = $this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO], $atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
                $strNomeCampo = ":" . $key;
                if ($item != 'NULL') {
                  $item = substr($item, 1, strlen($item) - 2);
                  $arrCampos[$strNomeCampo] = $item;
                  $strValues .= $strSeparador . $strNomeCampo;
                } else {
                  $strValues .= $strSeparador . $item;
                }/* TRE-TO fim - BIND clob - ORACLE*/
              } else { //outros Bancos ou valor n�o STR
                  $strValues .=  $strSeparador.$this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO],$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
              }

            }
            $strSeparador = ',';
          }

        }
        if ($bolExecIndividual) { //caso de BANCO ORACLE com BIND clob
          $sql = 'INSERT INTO '.$objInfraDTO->getStrNomeTabela().' (';
          $sql.= $strCampos;
          $sql .= ') VALUES ('.$strValues.')';
          if($bolRetornarSql) {
            $strRetorno.=$sql.";\n";
          } else {
            $this->getObjInfraIBanco()->executarSql($sql, $arrCampos/*TRE-TO*/);
          }
          $arrCampos=array();
        }
        $arrStrValues[]=$strValues;
        $strValues = '';
        $strSeparador = '';
        $bolPrimeiro=false;

      }

      if($bolExecIndividual) {
        if ($bolRetornarSql){
          return $strRetorno;
        } else {
          if ($bolMultiplo) {
            return $varObjInfraDTO;
          } else {
            return $varObjInfraDTO[0];
          }
        }
      } else {
        if ($bolOracle && $numRegistros>1){ //MULTIPLOS REGISTROS NO ORACLE
          $sql = 'INSERT ALL INTO '.$objInfraDTO->getStrNomeTabela().' (';
          $sql.= $strCampos;
          $sql .= ') VALUES ';
          $sql.='('.$arrStrValues[0].')';
          $strSeparador=',INTO '.$objInfraDTO->getStrNomeTabela().' ('.$strCampos.') VALUES ';
          for($i=1;$i<$numRegistros;$i++){
            $sql.=$strSeparador.'('.$arrStrValues[$i].')';
          }
          $sql.= 'SELECT 1 FROM DUAL';
        } else { // 1 REGISTRO OU OUTROS BANCOS
          $sql = 'INSERT INTO '.$objInfraDTO->getStrNomeTabela().' (';
          $sql.= $strCampos;
          $sql .= ') VALUES ';
          $sql .= '('.$arrStrValues[0].')';
          for($i=1;$i<$numRegistros;$i++){
            $sql.=',('.$arrStrValues[$i].')';
          }
        }
      }

      if ($bolRetornarSql){
        return $sql.';';
      }

      $this->getObjInfraIBanco()->executarSql($sql, $arrCampos/*TRE-TO*/);



//      $t = InfraUtil::verificarTempoProcessamento($t);
//      $m2 = memory_get_usage();
//      InfraDebug::getInstance()->gravar('M1: '.$m1);
//      InfraDebug::getInstance()->gravar('M2: '.$m2);
//      InfraDebug::getInstance()->gravar('USO: '.($m2-$m1));
//      InfraDebug::getInstance()->gravar('TEMPO: '.$t.' s');
      if ($bolMultiplo) {
        return $varObjInfraDTO;
      } else {
        return $varObjInfraDTO[0];
      }
    }catch(Exception $e){
      throw new InfraException('Erro cadastrando registro em '.$objInfraDTO->getStrNomeTabela().'.', $e, substr($sql,0,INFRA_TAM_MAX_LOG_SQL));
    }
    return null;
  }

  public function alterar($objInfraDTO, $bolRetornarSql=false){
    try {

      /*
      $m1 = memory_get_usage();
      $t = InfraUtil::verificarTempoProcessamento();
      */
      $bolOracle=$this->getObjInfraIBanco() instanceof InfraOracle;

      $objInfraDTO->montarChaves();

      $strSeparador = '';
      $arrAtributos = $objInfraDTO->getArrAtributos();
      $arrPK = $objInfraDTO->getArrPK();
      $arrCampos = array();

      $sql = 'UPDATE '.$objInfraDTO->getStrNomeTabela().' SET ';
      foreach($arrAtributos as $atributo){

        //Se � um atributo de banco e pertence a tabela do DTO
        if ($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null && $atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]===null){

          //Se n�o � chave-prim�ria e esta com o valor setado
          if (!isset($arrPK[$atributo[InfraDTO::$POS_ATRIBUTO_NOME]]) && ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_SET)){
            if($bolOracle && $atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_STR){
              /* TRE-TO inicio - BIND clob*/
              $item = $this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO],$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
              if($item!="NULL"){
                $strNomeCampo = ":".$atributo[InfraDTO::$POS_ATRIBUTO_NOME];
                $item = substr($item, 1,strlen($item)-2);
                $arrCampos[$strNomeCampo] = $item;
                $sql .= $strSeparador.$atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].'='.$strNomeCampo;
              }else{
                $sql .= $strSeparador.$atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].'='.$item;
              }
              /* TRE-TO fim - BIND clob*/
            }else{
              $sql .= $strSeparador.$atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].'='.$this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO],$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
            }
            $strSeparador = ',';
          }
        }
      }
      $sql .= ' '.$this->montarWherePK($objInfraDTO);

      if ($bolRetornarSql){
        return $sql.';';
      }
      //  echo $sql; exit;
      $numReg = $this->getObjInfraIBanco()->executarSql($sql, $arrCampos/*TRE-TO*/);

      if ($numReg==0){
        throw new InfraException('Registro n�o encontrado em '.$objInfraDTO->getStrNomeTabela().'.',null,$sql);
      }

      /*
      $t = InfraUtil::verificarTempoProcessamento($t);
      $m2 = memory_get_usage();
      InfraDebug::getInstance()->gravar('M1: '.$m1);
      InfraDebug::getInstance()->gravar('M2: '.$m2);
      InfraDebug::getInstance()->gravar('USO: '.($m2-$m1));
      InfraDebug::getInstance()->gravar('TEMPO: '.$t.' s');
      */

    }catch(Exception $e){
      throw new InfraException('Erro alterando registro de '.$objInfraDTO->getStrNomeTabela().'.',$e,substr($sql,0,INFRA_TAM_MAX_LOG_SQL));
    }
    return null;
  }

  public function excluir($objInfraDTO, $bolRetornarSql=false){
    try {
      $sql = '';
      $objInfraDTO->montarChaves();

      $sql = 'DELETE FROM '.$objInfraDTO->getStrNomeTabela().$this->montarWherePK($objInfraDTO);

      if ($bolRetornarSql){
        return $sql.';';
      }

      $numReg = $this->getObjInfraIBanco()->executarSql($sql);

      if ($numReg==0){
        throw new InfraException('Registro n�o encontrado em '.$objInfraDTO->getStrNomeTabela().'.',null,$sql);
      }

    }catch(Exception $e){
      throw new InfraException('Erro excluindo registro em '.$objInfraDTO->getStrNomeTabela().'.',$e,$sql);
    }
    return null;
  }

  public function consultar($objInfraDTO, $bolRetornarSql=false){
    try {
      //$objInfraDTO->montarChaves();
      $ret = $this->listar($objInfraDTO, $bolRetornarSql);

      if ($bolRetornarSql){
        return $ret;
      }

      $numRegistros = count($ret);

      //Retornou 1 registro OK
      //Crit�rios informados s�o uma chave-prim�ria ou chave-candidata
      if ($numRegistros===1){
        $objDTO = $ret[0];
        //Nada foi encontrado OK
      }else if ($numRegistros===0){
        $objDTO = null;
        //Retornou mais de um registro, crit�rios informados n�o identificam
        //unicamente um registro na tabela ERRO
      }else{
        throw new InfraException('Consulta retornou mais de um registro de '.strtoupper($objInfraDTO->getStrNomeTabela()).'.',null,$this->strSql);
      }
      return $objDTO;

    }catch(Exception $e){
      throw new InfraException('Erro consultando registro de '.$objInfraDTO->getStrNomeTabela().'.',$e,$this->strSql);
    }
    return null;
  }

  public function desativar($objInfraDTO, $bolRetornarSql=false){
    try {
      $sql = '';
      $objInfraDTO->montarChaves();

      $sql = 'UPDATE '.$objInfraDTO->getStrNomeTabela();
      $sql .= ' SET sin_ativo=\'N\' ';
      $sql .= $this->montarWherePK($objInfraDTO);

      if ($bolRetornarSql){
        return $sql.';';
      }

      $numReg = $this->getObjInfraIBanco()->executarSql($sql);

      if ($numReg==0){
        throw new InfraException('Registro de '.$objInfraDTO->getStrNomeTabela().' n�o encontrado para desativa��o.',null,$sql);
      }

    }catch(Exception $e){
      throw new InfraException('Erro desativando registro de '.$objInfraDTO->getStrNomeTabela().'.',$e,$sql);
    }
    return null;
  }

  public function reativar($objInfraDTO, $bolRetornarSql=false){
    try {
      $sql = '';
      $objInfraDTO->montarChaves();

      $sql = 'UPDATE '.$objInfraDTO->getStrNomeTabela();
      $sql .= ' SET sin_ativo=\'S\' ';
      $sql .= $this->montarWherePK($objInfraDTO);

      if ($bolRetornarSql){
        return $sql.';';
      }

      $numReg = $this->getObjInfraIBanco()->executarSql($sql);
      if ($numReg==0){
        throw new InfraException('Registro de '.$objInfraDTO->getStrNomeTabela().' n�o encontrado para reativa��o.',null,$sql);
      }

    }catch(Exception $e){
      throw new InfraException('Erro reativando registro de '.$objInfraDTO->getStrNomeTabela().'.',$e,$sql);
    }
    return null;
  }

  public function contar($objInfraDTO, $bolRetornarSql=false) {
    try {
      $objInfraDTO->montarChaves();
      $strRet = '';
      $strSeparador = '';

      if ($objInfraDTO->getDistinct()) {
        $arrAtributos = $objInfraDTO->getArrAtributos();
        foreach ($arrAtributos as $atributo) {
          if ($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL] !== null) {
            if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_RET) {
              $strRet .= $strSeparador;
              $strRet .=  $this->selecionarCampo($objInfraDTO, $atributo);
              $strSeparador = ',';
            }
          }
        }

        if ($strRet != '') {
          $sql = 'SELECT COUNT(*) AS total FROM (SELECT DISTINCT '.$strRet.' '.$this->montarFromJoinWhere($objInfraDTO).') Temp';
        }
      }

      if ((!$objInfraDTO->getDistinct()) || ($strRet == '')) {
        $sql = 'SELECT COUNT(*) AS total '.$this->montarFromJoinWhere($objInfraDTO);
      }

      if ($bolRetornarSql){
        return $sql.';';
      }

      $rs = $this->getObjInfraIBanco()->consultarSql($sql);

      if (!isset($rs[0]['total'])){
        throw new InfraException('Contagem n�o retornou nenhum valor.',null,$sql);
      }

      if (!is_numeric($rs[0]['total'])){
        throw new InfraException('Contagem n�o retornou valor num�rico.',null,$sql);
      }

      return $rs[0]['total'];

    }catch(Exception $e){
      throw new InfraException('Erro contando registros de '.$objInfraDTO->getStrNomeTabela().'.',$e,$sql);
    }
    return null;
  }

  public function listar($objInfraDTO, $bolRetornarSql=false) {
    try {
      $sql = '';
      $objInfraDTO->montarChaves();

      $this->gerarAlias($objInfraDTO);

      $sql .= $this->montarSelect($objInfraDTO);
      $sql .= $this->montarFromJoinWhere($objInfraDTO);
      $sql .= $this->montarOrderBy($objInfraDTO);

      if ($objInfraDTO->getStrSubSelectSqlNativo()!=null){
        $sql = str_replace('INFRA_SQL', $sql, $objInfraDTO->getStrSubSelectSqlNativo());
      }

      if ($objInfraDTO->getStrSqlPesquisa()!==null && $objInfraDTO->getStrSqlSubstituicao()!==null){
        $sql = str_replace($objInfraDTO->getStrSqlPesquisa(), $objInfraDTO->getStrSqlSubstituicao(), $sql);
      }

      if ($bolRetornarSql){
        return $sql.';';
      }

      //Sem pagina��o
      if ($objInfraDTO->getNumPaginaAtual()===null){
        if ($objInfraDTO->getNumMaxRegistrosRetorno()===null){
          $rs = $this->getObjInfraIBanco()->consultarSql($sql);
        }else{
          $rs = $this->getObjInfraIBanco()->limitarSql($sql,$objInfraDTO->getNumMaxRegistrosRetorno());
        }
        //Com pagina��o
      }else{
        $pag = $this->getObjInfraIBanco()->paginarSql($sql,$objInfraDTO->getNumPaginaAtual()*$objInfraDTO->getNumMaxRegistrosRetorno(),$objInfraDTO->getNumMaxRegistrosRetorno());
        $objInfraDTO->setNumTotalRegistros($pag['totalRegistros']);
        $objInfraDTO->setNumRegistrosPaginaAtual(count($pag['registrosPagina']));
        $rs = $pag['registrosPagina'];
      }


      $arrObjInfraDTO = array();

      /*
      $numReg = count($rs);
      for($i=0;$i<$numReg;$i++){
        $arrObjInfraDTO[$i]=$this->montarDTORetorno($objInfraDTO,$rs[$i]);
      }
      */

      $reflectionClass = new ReflectionClass(get_class($objInfraDTO));
      $arrAtributos = $objInfraDTO->getArrAtributos();
      $arrKeys = array_keys($arrAtributos);
      $arrKeysRet = array();
      foreach($arrKeys as $key){
        if ( $arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null && $arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_RET){
          $arrKeysRet[] = $key;
        }
      }


      /*
      $numReg = count($rs);
      for($i=0;$i<$numReg;$i++){
        $objRet = $reflectionClass->newInstance();
        $arrAtributosRet = array();

        foreach($arrKeysRet as $key){
          $valor = $this->lerCampo($arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO],$rs[$i][$this->arrAlias[$key]]);
          $arrAtributosRet[$key][InfraDTO::$POS_ATRIBUTO_VALOR] = $valor;
          $arrAtributosRet[$key][InfraDTO::$POS_ATRIBUTO_FLAGS] = InfraDTO::$FLAG_SET | InfraDTO::$FLAG_IGUAL;
        }

        $objRet->setArrAtributos($arrAtributosRet);
        $arrObjInfraDTO[$i] = $objRet;
      }
      */

      foreach($rs as $item){
        $objRet = $reflectionClass->newInstance();
        $arrAtributosRet = array();

        foreach($arrKeysRet as $key){
          $valor = $this->lerCampo($arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO],$item[$this->arrAlias[$key]]);
          $arrAtributosRet[$key][InfraDTO::$POS_ATRIBUTO_VALOR] = $valor;
          $arrAtributosRet[$key][InfraDTO::$POS_ATRIBUTO_FLAGS] = InfraDTO::$FLAG_SET | InfraDTO::$FLAG_IGUAL;
        }

        $objRet->setArrAtributos($arrAtributosRet);
        $arrObjInfraDTO[] = $objRet;
      }

      //$rs = null;
      //unset($rs);

      $this->strSql = $sql;

      return $arrObjInfraDTO;

    }catch(Exception $e){
      throw new InfraException('Erro listando registros de '.$objInfraDTO->getStrNomeTabela().'.',$e,$sql);
    }
    return null;
  }

  public function bloquear($objInfraDTO, $bolRetornarSql=false){
    try {

      $objInfraDTO->montarChaves();

      $reflectionClass = new ReflectionClass(get_class($objInfraDTO));
      $dto = $reflectionClass->newInstance();

      //retornar atributos da tabela
      $dto->retTodos();

      //seta apenas chave prim�ria
      $arrPK = $objInfraDTO->getArrPK();
      $arrAtributos = $objInfraDTO->getArrAtributos();
      if ($arrPK!=null){
        $arrKeys = array_keys($arrPK);
        foreach($arrKeys as $key){
          $valor = call_user_func(array($objInfraDTO,'get'.$arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO].$key));
          call_user_func(array($dto,'set'.$arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO].$key),$valor);
        }
      }
      $sqlIngres = '';
      if ($this->getObjInfraIBanco() instanceof InfraIngres){

        //$sqlIngres = 'set lockmode session where readlock=exclusive, timeout=30';
        $sqlIngres = 'set lockmode session where level=row, readlock=exclusive, timeout=30';

        if (!$bolRetornarSql){
          $this->getObjInfraIBanco()->executarSql($sqlIngres);
        }
      }

      $dto->montarChaves();
      $this->gerarAlias($dto);

      $sql = '';
      $sql .= $this->montarSelect($dto);
      $sql .= $this->montarFrom($dto);

      if ($this->getObjInfraIBanco() instanceof InfraSqlServer ){
        $sql .= ' WITH (HOLDLOCK ROWLOCK) ';
      }

      $sql .= $this->montarWherePK($dto);

      if ($this->getObjInfraIBanco() instanceof InfraMySql ||
          $this->getObjInfraIBanco() instanceof InfraOracle ||
          $this->getObjInfraIBanco() instanceof InfraIngres ||
          $this->getObjInfraIBanco() instanceof InfraPostgreSql){
        $sql .= ' FOR UPDATE';
      }

      if ($bolRetornarSql){
        return $sqlIngres.$sql.';';
      }

      $rs = $this->getObjInfraIBanco()->consultarSql($sql);

      $numRegistros = count($rs);

      if ($numRegistros===1){
        $dto = $this->montarDTORetorno($dto,$rs[0]);
      }else if ($numRegistros===0){
        $dto = null;
      }else if ($numRegistros > 1){
        throw new InfraException('Mais de um registro encontrado para bloqueio.',null,$sql);
      }

      return $dto;

    }catch(Exception $e){
      throw new InfraException('Erro bloqueando registro em '.$objInfraDTO->getStrNomeTabela().'.',$e,$sql);
    }
    return null;
  }

  private function obterPrefixoCampo($objInfraDTO, $atributo){
    $strRet = null;
    //Se tem Fks coloca prefixo na frente do campos
    if (is_array($objInfraDTO->getArrFK())){
      //atributos da propria tabela tem tab_origem nulo
      if ($atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]===null){
        $strRet = $objInfraDTO->getStrNomeTabela();
      } else {
        //Se tem espaco no nome da tabela assume que foi dado um alias
        //e este j� foi referenciado pelo usuario ao adicionar o campo no DTO
        if (strpos($atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM],' ')===false){
          $strRet = $atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM];
        }
      }
    }
    return $strRet;
  }

  private function montarPrefixoCampo($objInfraDTO, $atributo){
    $strRet = $this->obterPrefixoCampo($objInfraDTO,$atributo);
    if ($strRet!==null){
      $strRet .= '.';
    }
    return $strRet;
  }

  protected function montarSelect($objInfraDTO) {

    $strRet = '';
    $strSeparador = '';

    $arrAtributos = $objInfraDTO->getArrAtributos();
    foreach($arrAtributos as $atributo){
      if ($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null){
        if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_RET){
          $strRet .= $strSeparador;
          $strRet .=  $this->selecionarCampo($objInfraDTO,$atributo);
          $strSeparador = ',';
        }
      }
    }

    if ($strRet==''){
      throw new InfraException('Nenhum campo solicitado para retorno no DTO.');
    }

    $strSelect = '';
    if (!$objInfraDTO->getDistinct()){
      $strSelect = 'SELECT ';
    }else{
      $strSelect = 'SELECT DISTINCT ';
    }

    $strSelect .= $strRet;

    return $strSelect;
  }
  /*
  FROM accounting_link_invoice AS a

  LEFT OUTER JOIN accounting_link_payment AS pmt
  ON a.contact_id = pmt.contact_id
  AND a.property_id = pmt.property_id
  AND a.invoice_id = pmt.invoice_id
  AND pmt.accounting_date <= CONVERT(datetime, '05/22/2007')

  LEFT OUTER JOIN accounting_link_credit AS cm
  ON a.contact_id = cm.contact_id
  AND a.property_id = cm.property_id
  AND a.invoice_id = cm.invoice_id
  AND cm.accounting_date <= CONVERT(datetime, '05/22/2007')

  WHERE (a.property_id = 921)
  AND (a.accounting_date <= CONVERT(datetime, '05/22/2007'))
  AND (a.contact_id = 929)


  SELECT tblalunos.nome, tblcursos.nomecurso, tblnotas.nota
  FROM tblcursos
  INNER JOIN
  (tblalunos INNER JOIN tblnotas
  ON tblalunos.codaluno = tblnotas.codaluno)
  ON tblcursos.codcurso = tblnotas.codcurso
  ORDER BY tblalunos.nome;


  SELECT administrador_sistema.id_usuario,administrador_sistema.id_sistema,usuario.sigla AS infra_campo_rel_1,sistema.sigla AS infra_campo_rel_2,usuario.id_orgao AS infra_campo_rel_3,a.sigla AS infra_campo_rel_4,sistema.id_orgao AS infra_campo_rel_5,b.sigla AS infra_campo_rel_6
  FROM administrador_sistema
  INNER JOIN usuario ON administrador_sistema.id_usuario=usuario.id_usuario
  INNER JOIN sistema ON administrador_sistema.id_sistema=sistema.id_sistema
  INNER JOIN orgao a ON usuario.id_orgao=a.id_orgao
  INNER JOIN orgao b ON sistema.id_orgao=b.id_orgao
  ORDER BY sistema.sigla ASC

  SELECT administrador_sistema.id_usuario,administrador_sistema.id_sistema,usuario.sigla AS infra_campo_rel_1,sistema.sigla AS infra_campo_rel_2,usuario.id_orgao AS infra_campo_rel_3,a.sigla AS infra_campo_rel_4,sistema.id_orgao AS infra_campo_rel_5,b.sigla AS infra_campo_rel_6
  FROM administrador_sistema
  INNER JOIN (usuario INNER JOIN orgao a ON usuario.id_orgao=a.id_orgao) ON administrador_sistema.id_usuario=usuario.id_usuario
  INNER JOIN (sistema INNER JOIN orgao b ON sistema.id_orgao=b.id_orgao) ON administrador_sistema.id_sistema=sistema.id_sistema
  ORDER BY sistema.sigla ASC

  SELECT serie.id_serie,serie.nome,tipo_serie.nome AS infra_campo_rel_1
  FROM serie
  INNER JOIN tipo_serie ON serie.id_tipo_serie=tipo_serie.id_tipo_serie
  WHERE serie.id_tipo_serie='2'
  AND serie.sin_ativo='S'
  ORDER BY serie.nome ASC

  */

  private function carregarArrJoin($objInfraDTO,$tabelaOrigem, &$arr){
    $arrFK = $objInfraDTO->getArrFK();
    if (is_array($arrFK)){
      $arrAtributos = $objInfraDTO->getArrAtributos();
      $arrNomesTabelasFK = array_keys($arrFK);
      foreach($arrNomesTabelasFK as $nomeTabelaFK){
        $arrAtributosFK = array_keys($arrFK[$nomeTabelaFK]);
        foreach($arrAtributosFK as $nomeAtributoFK){
          if ($arrAtributos[$nomeAtributoFK][InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]===$tabelaOrigem){
            if ($tabelaOrigem===null){
              $tab = $objInfraDTO->getStrNomeTabela();
            }else{
              $tab = $tabelaOrigem;
            }

            $numReg = count($arr);

            for($i=0;$i<$numReg;$i++){
              if ($arr[$i][0]==$tab && $arr[$i][1]==$nomeTabelaFK){
                break;
              }
            }

            //Se n�o existe no array (chaves-compostas)
            if ($i==$numReg){
              $n = $numReg;
              $arr[$n] = array();
              $arr[$n][0] = $tab;
              $arr[$n][1] = $nomeTabelaFK;
              $this->carregarArrJoin($objInfraDTO,$nomeTabelaFK,$arr);
            }
          }
        }
      }
    }
  }

  private function isLeftJoin($objInfraDTO){
    $arrFK = $objInfraDTO->getArrFK();

    if (is_array($arrFK)){
      //obtem tabelas referenciadas (primeira dimensao do array de fks)
      $arrNomesTabelasFK = array_keys($arrFK);

      //Para cada tabela referenciada
      foreach ($arrNomesTabelasFK as $nomeTabelaFK){
        $arrNomesAtributosFK = array_keys($arrFK[$nomeTabelaFK]);
        //Pega o tipo configurado no primeiro atributo da FK
        if( $arrFK[$nomeTabelaFK][$arrNomesAtributosFK[0]][InfraDTO::$POS_FK_TIPO]==InfraDTO::$TIPO_FK_OPCIONAL){
          return true;
        }
      }
    }
    return false;
  }

  private function getTipoJoin($objInfraDTO,$strTabPK, $strTabFK){
    $arrFK = $objInfraDTO->getArrFK();

    //obtem tabelas referenciadas (primeira dimensao do array de fks)
    $arrNomesTabelasFK = array_keys($arrFK);

    //Para cada tabela referenciada
    foreach ($arrNomesTabelasFK as $nomeTabelaFK){
      if ($strTabFK === $nomeTabelaFK){
        $arrNomesAtributosFK = array_keys($arrFK[$nomeTabelaFK]);

        //Pega o tipo configurado no primeiro atributo da FK
        $numTipoFK = $arrFK[$nomeTabelaFK][$arrNomesAtributosFK[0]][InfraDTO::$POS_FK_TIPO];
        if ($numTipoFK==InfraDTO::$TIPO_FK_OBRIGATORIA){
          return ' INNER JOIN ';
        }else{
          return ' LEFT JOIN ';
        }
      }
    }
  }

  /*
00038 - #documento-->subserie
00039 - #documento-->protocolo
00040 - #protocolo-->unidade a
00041 - #protocolo-->publicacao

FROM documento
INNER JOIN @1@subserie ON documento.id_subserie=subserie.id_subserie
INNER JOIN @2@(protocolo INNER JOIN @6@unidade a%3% ON protocolo.id_unidade_geradora=a.id_unidade)%1% ON documento.id_documento=protocolo.id_protocolo

*/

  private function montarOn($objInfraDTO,$tab1,$tab2){
    $strOn = '';
    $strSeparador = '';
    $arrAtributos = $objInfraDTO->getArrAtributos();


    //Se o array de fks existe
    if (is_array($objInfraDTO->getArrFK())){

      //Recupera as chaves estrangeiras montadas
      $arrFK = $objInfraDTO->getArrFK();

      //obtem tabelas referenciadas (primeira dimensao do array de fks)
      $arrNomesTabelasFK = array_keys($arrFK);

      //Para cada tabela referenciada
      foreach ($arrNomesTabelasFK as $nomeTabelaFK){

        if ($tab2 === $nomeTabelaFK){
          $strOn .= ' ON ';

          //Obtem atributos FK do DTO que apontam para a tabela referenciada
          $arrNomesAtributosFK = array_keys($arrFK[$nomeTabelaFK]);

          //Monta cruzamento entre as tabelas
          $strSeparador = '';
          foreach ($arrNomesAtributosFK as $nomeAtributoFK) {
            $strOn .= $strSeparador;

            //Testa se n�o � join entre outras tabelas, pode ser adicionado no
            //DTO campos estrangeiros e for�ar um join de outras tabelas
            $strOn .= $this->montarPrefixoCampo($objInfraDTO,$arrAtributos[$nomeAtributoFK]).$arrAtributos[$nomeAtributoFK][InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];

            //Adiciona a tabela e campo sql FK relacionados ao atributo
            $strOn .= '=';

            //Se tem espaco no nome da tabela assume que foi usado um alias
            //e que o campo foi adicionado no DTO considerando isso
            if (strpos($nomeTabelaFK,' ')===false){
              $strOn .= $nomeTabelaFK.'.'.$arrFK[$nomeTabelaFK][$nomeAtributoFK][InfraDTO::$POS_FK_CAMPO];
            }else{
              $strOn .= $arrFK[$nomeTabelaFK][$nomeAtributoFK][InfraDTO::$POS_FK_CAMPO];
            }
            $strSeparador = ' AND ';
          }

          //pega o filtro (ON/WHERE) configurado na primeira FK
          if ($arrFK[$nomeTabelaFK][$arrNomesAtributosFK[0]][InfraDTO::$POS_FK_FILTRO]==InfraDTO::$FILTRO_FK_ON){

            //Monta filtros para campos da outra tabela que foram setados
            foreach($arrAtributos as $atributo){
              if ($atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]==$nomeTabelaFK){
                if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_SET){
                  $strOn .= $strSeparador;
                  $strOn .= $this->montarCondicao($objInfraDTO,$atributo,$objInfraDTO->getOperador($atributo),$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
                  $strSeparador = ' AND ';
                }
              }
            }

            //Monta os criterios/grupos que referenciam apenas as tabelas 1 e 2
            $strCriterios = $this->montarCriterios($objInfraDTO,array($tab1,$tab2));
            if ($strCriterios!=''){
              $strOn .= $strSeparador.$strCriterios;
              $strSeparador = ' AND ';
            }
          }
        }
      }
    }
    return $strOn;
  }

  /*
  SELECT tabela.id_tabela,tabela.id_isolada_pk_1,tabela.id_isolada_pk_2,tabela.id_nivel_3,tabela.atributo,tabela.id_relacionada_1,tabela.id_relacionada_2,nivel_3.nome AS infra_campo_rel_1,nivel_2.nome AS infra_campo_rel_2,nivel_1.nome AS infra_campo_rel_3,nivel_3.id_nivel_2_pk_1 AS infra_campo_rel_4,nivel_3.id_nivel_2_pk_2 AS infra_campo_rel_5,nivel_1.atributo_a AS infra_campo_rel_6,nivel_1.atributo_b AS infra_campo_rel_7,nivel_2.id_nivel_1 AS infra_campo_rel_8,relacionada_1.nome AS infra_campo_rel_9,relacionada_2.nome AS infra_campo_rel_10,relacionada_1.id_tipo_relacionada AS infra_campo_rel_11,a.nome AS infra_campo_rel_12,relacionada_2.id_tipo_relacionada AS infra_campo_rel_13,b.nome AS infra_campo_rel_14,isolada.nome AS infra_campo_rel_15
  FROM tabela
  LEFT JOIN isolada ON tabela.id_isolada_pk_1=isolada.id_isolada_pk_1 AND tabela.id_isolada_pk_2=isolada.id_isolada_pk_2
  LEFT JOIN (nivel_3 LEFT JOIN (nivel_2 LEFT JOIN nivel_1 ON nivel_2.id_nivel_1=nivel_1.id_nivel_1) ON nivel_3.id_nivel_2_pk_1=nivel_2.id_nivel_2_pk_1 AND nivel_3.id_nivel_2_pk_2=nivel_2.id_nivel_2_pk_2) ON tabela.id_nivel_3=nivel_3.id_nivel_3
  INNER JOIN (relacionada_1 INNER JOIN tipo_relacionada a ON relacionada_1.id_tipo_relacionada=a.id_tipo_relacionada) ON tabela.id_relacionada_1=relacionada_1.id_relacionada_1
  LEFT JOIN (relacionada_2 INNER JOIN tipo_relacionada b ON relacionada_2.id_tipo_relacionada=b.id_tipo_relacionada) ON tabela.id_relacionada_2=relacionada_2.id_relacionada_2
  WHERE tabela.id_tabela='1'
  */

  /*
  00037 - #login-->sistema
  00038 - #sistema-->orgao s
  00039 - #login-->usuario
  00040 - #login-->contexto
  00041 - #contexto-->orgao c
  */

  private function montarArvore($arrJoin,$objInfraDTO){
    $arrArvore = array();
    foreach($arrJoin as $join){
      if (!$this->adicionarFolhaArvore($join[0],$join[1],$arrArvore,$objInfraDTO)){

        if (!isset($arrArvore[$join[0]])){
          $arrArvore[$join[0]] = array();
        }

        $arrArvore[$join[0]][$join[1]] = null;

        //InfraDebug::getInstance()->gravar('@2'.$join[0].' - '.$join[1]);
      }
    }
    return $arrArvore;
  }

  private function adicionarFolhaArvore($tab1,$tab2,&$arr,$objInfraDTO){

    foreach(array_keys($arr) as $tab){
      if ($tab==$tab1){
        if ($arr[$tab1]===null){
          $arr[$tab1] = array();
        }
        $arr[$tab1][$tab2] = null;
        //InfraDebug::getInstance()->gravar('@1'.$tab1.' - '.$tab2);
        return true;
      }else if (is_array($arr[$tab])){
        if ($this->adicionarFolhaArvore($tab1,$tab2,$arr[$tab],$objInfraDTO)){;
          return true;
        }
      }
    }
    return false;
  }

  /*
  arr[login][sistema]
  arr[login][sistema][orgao s]
  */

  private function montarJoinRaiz($arrArvore,$arrJoin,$objInfraDTO,&$str){
    foreach(array_keys($arrArvore) as $raiz){
      $str .= $raiz.' ';
      $str .= $this->montarJoinFilhos($arrArvore[$raiz],$raiz,$arrJoin,$objInfraDTO,$str);
    }
  }

  private function montarJoinFilhos($arr,$pai,$arrJoin,$objInfraDTO,&$str){
    foreach(array_keys($arr) as $tab){
      $str .= $this->getTipoJoin($objInfraDTO,$pai,$tab);
      if (is_array($arr[$tab])){
        $str .= ' (';
        $str .= $tab;
        $str .= $this->montarJoinFilhos($arr[$tab],$tab,$arrJoin,$objInfraDTO,$str);
        $str .= ')';
      }else{
        $str .= $tab;
      }
      $str .= ' '.$this->montarOn($objInfraDTO,$pai,$tab);
    }
  }

  protected function montarFromJoinWhere($objInfraDTO){
    $this->arrCriteriosProcessados = array();
    $this->arrGruposProcessados = array();

    //Se n�o possui relacionamentos opcionais OU � MUMPS (que n�o aceita sintaxe INNER JOIN e LEFT JOIN)
    //if (!$this->isLeftJoin($objInfraDTO) || $this->getObjInfraIBanco() instanceof InfraMumps){
    if ($this->getObjInfraIBanco() instanceof InfraMumps){
      $strFrom = $this->montarFrom($objInfraDTO);
      $strWhere = $this->montarWhere($objInfraDTO);
      return $strFrom.$strWhere;
    }

    $strFrom = '';
    $strJoin = '';
    $strWhere = '';
    $strSeparador = '';
    $arrAtributos = $objInfraDTO->getArrAtributos();

    $strFrom = ' FROM ';

    /*
    $arrFK = $objInfraDTO->getArrFK();
    if (is_array($arrFK)){
      $arrNomesTabelasFK = array_keys($arrFK);
      foreach ($arrNomesTabelasFK as $nomeTabelaFK){
         $arrNomesAtributosFK = array_keys($arrFK[$nomeTabelaFK]);
         foreach ($arrNomesAtributosFK  as $a){
           InfraDebug::getInstance()->gravar('@'.$nomeTabelaFK.'->'.$a);
         }
      }
    }

    00012 - @isolada->IdIsoladaPk1
    00013 - @isolada->IdIsoladaPk2
    00014 - @nivel_3->IdNivel3
    00015 - @nivel_2->IdNivel2Pk1
    00016 - @nivel_2->IdNivel2Pk2
    00017 - @nivel_1->IdNivel1
    00018 - @relacionada_1->IdRelacionada1
    00019 - @relacionada_2->IdRelacionada2
    00020 - @tipo_relacionada a->IdTipoRelacionada1
    00021 - @tipo_relacionada b->IdTipoRelacionada2
    */

    $arrJoin = array();
    $this->carregarArrJoin($objInfraDTO,null,$arrJoin);
    //foreach($arrJoin as $join){
    //  InfraDebug::getInstance()->gravar('#'.$join[0].'-->'.$join[1]);
    //}

    if (count($arrJoin)==0){
      $strFrom .= $objInfraDTO->getStrNomeTabela();
    }else{

      /*
      00022 - #tabela-->isolada
      00023 - #tabela-->nivel_3
      00024 - #nivel_3-->nivel_2
      00025 - #nivel_2-->nivel_1
      00026 - #tabela-->relacionada_1
      00027 - #relacionada_1-->tipo_relacionada a
      00028 - #tabela-->relacionada_2
      00029 - #relacionada_2-->tipo_relacionada b
      */


      $strJoin = '';
      $arrArvore = $this->montarArvore($arrJoin,$objInfraDTO);

      //InfraDebug::getInstance()->gravar(print_r($arrArvore,true));

      $this->montarJoinRaiz($arrArvore,$arrJoin,$objInfraDTO,$strJoin);
    }

    //Monta WHERE para campos da tabela principal
    $strSeparador = '';
    foreach($arrAtributos as $atributo){
      if ($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null && $atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]===null){
        if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_SET){
          $strWhere .= $strSeparador;
          $strWhere .= $this->montarCondicao($objInfraDTO,$atributo,$objInfraDTO->getOperador($atributo),$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
          $strSeparador = ' AND ';
        }
      }
    }

    /////////////////////////////////////////////////

    if (is_array($objInfraDTO->getArrFK())){

      //Recupera as chaves estrangeiras montadas
      $arrFK = $objInfraDTO->getArrFK();

      //obtem tabelas referenciadas (primeira dimensao do array de fks)
      $arrNomesTabelasFK = array_keys($arrFK);

      //Para cada tabela referenciada
      foreach ($arrNomesTabelasFK as $nomeTabelaFK){

        //Obtem atributos FK do DTO que apontam para a tabela referenciada
        $arrNomesAtributosFK = array_keys($arrFK[$nomeTabelaFK]);

        //pega o filtro (ON/WHERE) configurado na primeira FK
        if ($arrFK[$nomeTabelaFK][$arrNomesAtributosFK[0]][InfraDTO::$POS_FK_FILTRO]==InfraDTO::$FILTRO_FK_WHERE){

          foreach($arrAtributos as $atributo){
            if ($atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]==$nomeTabelaFK){
              if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_SET){
                $strWhere .= $strSeparador;
                $strWhere .= $this->montarCondicao($objInfraDTO,$atributo,$objInfraDTO->getOperador($atributo),$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
                $strSeparador = ' AND ';
              }
            }
          }
        }
      }
    }

    $strCriterios = $this->montarCriterios($objInfraDTO);
    if ($strCriterios != ''){
      $strWhere .= $strSeparador.$strCriterios;
      $strSeparador = ' AND ';
    }

    /*
    if ($objInfraDTO->isBolConfigurouExclusaoLogica() && $objInfraDTO->isBolExclusaoLogica()){
      //Elimina registros excluidos logicamente
      $strWhere .= $strSeparador.$this->montarPrefixoCampo($objInfraDTO, $arrAtributos['SinAtivo']).'sin_ativo=\'S\'';
    }
    */

    if ($objInfraDTO->isBolConfigurouExclusaoLogica() && $objInfraDTO->isBolExclusaoLogica()){
      //Elimina registros excluidos logicamente
      $strWhere .= $strSeparador.$this->montarPrefixoCampo($objInfraDTO, $arrAtributos['SinAtivo']).'sin_ativo=\'S\'';
      $strSeparador = ' AND ';
    }

    if ($objInfraDTO->isSetStrCriterioSqlNativo()) {
      $strWhere .= $strSeparador.'('.$objInfraDTO->getStrCriterioSqlNativo().')';
    }

    if ($strWhere != ''){
      $strWhere = ' WHERE '.$strWhere;
    }

    return $strFrom.$strJoin.$strWhere;
  }

  private function montarCondicao($objInfraDTO, $atributo, $operador, $valor){
    $strRet = '';
    if ( $valor === null ) {
      $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
      if ($operador==InfraDTO::$OPER_IGUAL){
        $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].' IS NULL';
      }else if($operador==InfraDTO::$OPER_DIFERENTE){
        $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].' IS NOT NULL';
      }else{
        throw new InfraException('Compara��es com valores nulos somente s�o permitidas com os operadores de igualdade ou diferen�a.');
      }
    } else {
      //Testa opera��o in
      if ($operador==InfraDTO::$OPER_IN || $operador==InfraDTO::$OPER_NOT_IN){

        if (!is_array($valor)) {
          throw new InfraException('Array inv�lido processando operador ' . $operador . '.');
        }

        if ($this->getObjInfraIBanco() instanceof InfraOracle && count($valor) > 1000){

          $strRet .= '(';
          $arrPartes = array_chunk($valor, 1000);
          $strOr = '';
          foreach($arrPartes as $arrParte){
            if ($strOr !='' ) {
              $strRet .= $strOr;
            }
            $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
            $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL] . ' ' . $operador . ' (';
            $strVirgula = '';
            foreach ($arrParte as $v) {
              $strRet .= $strVirgula . $this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO], $v);
              $strVirgula = ',';
            }
            $strRet .= ') ';
            $strOr = ' '.InfraDTO::$OPER_LOGICO_OR.' ';
          }
          $strRet .= ')';

        }else {
          $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
          $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL] . ' ' . $operador . ' (';
          $strVirgula = '';
          foreach ($valor as $v) {
            $strRet .= $strVirgula . $this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO], $v);
            $strVirgula = ',';
          }
          $strRet .= ') ';
        }
      }else{

        //Chama metodo de formatacao de pesquisa espec�fico
        if ($operador==InfraDTO::$OPER_LIKE || $operador==InfraDTO::$OPER_NOT_LIKE) {

          if ($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_STR){
            $strCampo = $this->montarPrefixoCampo($objInfraDTO, $atributo).$atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];
            $strValor = $valor;
          }else if ($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_NUM || $atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_DBL || $atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_DIN){
            $strCampo = $this->getObjInfraIBanco()->converterStr($this->obterPrefixoCampo($objInfraDTO, $atributo),$atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]);
            $strValor = $this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO],$valor);
            $strValor = str_replace('\'','',$strValor);
          }else{
            throw new InfraException('Operador LIKE n�o pode ser utilizado com atributos do tipo '.$atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO].'.');
          }

          if ($atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM]===null){
            $strTabela = $objInfraDTO->getStrNomeTabela();
          }else{
            $strTabela = $atributo[InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM];
          }

          $bolCaseInsensitive = $objInfraDTO->isBolCaseInsensitive($atributo);

          //n�o informado pega default do banco
          if ($bolCaseInsensitive===null){
            $bolCaseInsensitive = $this->getObjInfraIBanco()->isBolForcarPesquisaCaseInsensitive();
          }

          $strRet .= $this->getObjInfraIBanco()->formatarPesquisaStr($strTabela, $strCampo, $strValor, $operador, $bolCaseInsensitive);

        }else if (is_object($valor) && $valor instanceof InfraAtributoDTO) {

          $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
          $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].$operador;

          $arrAtributoParametro = $valor->getArrAtributo();
          $strRet .= $this->montarPrefixoCampo($objInfraDTO, $arrAtributoParametro);
          $strRet .= $arrAtributoParametro[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];

        }else {
          //Se o valor for vazio '' tem que fazer um tratamento espec�fico porque as classes de banco
          //convertem '' para NULL. Neste caso, n�o deve ser convertido '' para NULL porque nunca seria
          //poss�vel fazer uma busca em um banco legado por vazio ('').
          //Bancos novos que s� utilizaram a InfraPHP n�o deveriam ter valores vazios ('') pois no cadastro
          //e inser��o estes valores s�o convertidos para NULL
          if ($valor===''){
            $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
            $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].$operador.'\'\'';
          }else{

            if ($this->getObjInfraIBanco() instanceof InfraOracle && $atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO]==InfraDTO::$PREFIXO_STR){
              $valor = str_replace('\'','\'\'',$valor);
            }

            $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
            $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL] . $operador . $this->gravarCampo($atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO], $valor);
          }
        }
      }
    }
    return $strRet;
  }

  protected function montarFrom($objInfraDTO) {

    $strRet = ' FROM '.$objInfraDTO->getStrNomeTabela();

    //monta as tabelas relacionadas (keys do array de fks do DTO)
    if (is_array($objInfraDTO->getArrFK())){
      $arrFK = array_keys($objInfraDTO->getArrFK());
      foreach($arrFK as $tabFK){
        $strRet .= ', '.$tabFK;
      }
    }
    return $strRet;
  }

  protected function montarWhere($objInfraDTO) {
    $strWhere = '';
    $strSeparador = '';

    $arrAtributos = $objInfraDTO->getArrAtributos();

    //Se o array de fks existe
    if (is_array($objInfraDTO->getArrFK())){

      //Recupera as chaves estrangeiras montadas
      $arrFK = $objInfraDTO->getArrFK();

      //obtem tabelas referenciadas (primeira dimensao do array de fks)
      $arrNomesTabelasFK = array_keys($arrFK);

      //Para cada tabela referenciada
      foreach ($arrNomesTabelasFK as $nomeTabelaFK){

        //Obtem atributos do DTO que apontam para a tabela referenciada
        $arrNomesAtributosFK = array_keys($arrFK[$nomeTabelaFK]);

        //Para cada atributo
        foreach ($arrNomesAtributosFK as $nomeAtributoFK) {
          $strWhere .= $strSeparador;

          //Testa se n�o � join entre outras tabelas, pode ser adicionado no
          //DTO campos estrangeiros e for�ar um join de outras tabelas
          $strWhere .= $this->montarPrefixoCampo($objInfraDTO,$arrAtributos[$nomeAtributoFK]).$arrAtributos[$nomeAtributoFK][InfraDTO::$POS_ATRIBUTO_CAMPO_SQL];

          //Adiciona a tabela e campo sql FK relacionados ao atributo
          $strWhere .= '=';

          //Se tem espaco no nome da tabela assume que foi usado um alias
          //e que o campo foi adicionado no DTO considerando isso
          if (strpos($nomeTabelaFK,' ')===false){
            $strWhere .= $nomeTabelaFK.'.'.$arrFK[$nomeTabelaFK][$nomeAtributoFK][InfraDTO::$POS_FK_CAMPO];
          }else{
            $strWhere .= $arrFK[$nomeTabelaFK][$nomeAtributoFK][InfraDTO::$POS_FK_CAMPO];
          }
          $strSeparador = ' AND ';
        }
      }
    }

    //Monta filtros para campos que foram setados
    foreach($arrAtributos as $atributo){
      if ($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null){
        if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_SET){
          $strWhere .= $strSeparador;
          $strWhere .= $this->montarCondicao($objInfraDTO,$atributo,$objInfraDTO->getOperador($atributo),$atributo[InfraDTO::$POS_ATRIBUTO_VALOR]);
          $strSeparador = ' AND ';
        }
      }
    }

    $strCriterios = $this->montarCriterios($objInfraDTO);
    if ($strCriterios != ''){
      $strWhere .= $strSeparador.$strCriterios;
      $strSeparador = ' AND ';
    }

    if ($objInfraDTO->isBolConfigurouExclusaoLogica() && $objInfraDTO->isBolExclusaoLogica()){
      //Elimina registros excluidos logicamente
      $strWhere .= $strSeparador.$this->montarPrefixoCampo($objInfraDTO, $arrAtributos['SinAtivo']).'sin_ativo=\'S\'';
    }


    if ($strWhere != ''){
      $strWhere = ' WHERE '.$strWhere;
    }

    return $strWhere;
  }

  private function montarCriterios($objInfraDTO,$arrTabelas=null){
    $strCriterios = '';
    $strSeparador = '';
    $arrGrupos = $objInfraDTO->getArrGruposCriterios();
    $arrCriterios = $objInfraDTO->getArrCriterios();


    //ADICIONA CRITERIOS NAO AGRUPADOS
    $numCriterios = count($arrCriterios);
    $numGrupos = count($arrGrupos);

    for($i=0;$i<$numCriterios;$i++){
      if (!in_array($i,$this->arrCriteriosProcessados)){
        //Se o crit�rio possui somente as tabelas informadas (processando LEFT JOIN ... ON ...)
        //descartando os crit�rios que possuem apenas atributos da tabela principal
        if ($this->verificarTabelasCriterios($objInfraDTO,$arrCriterios[$i],$arrTabelas)){

          //Varre os grupos de crit�rios existentes procurando pelo nome
          for($j=0;$j<$numGrupos;$j++){
            if (in_array($arrCriterios[$i][InfraDTO::$POS_CRITERIO_NOME],$arrGrupos[$j][InfraDTO::$POS_GRUPO_CRITERIO_CRITERIOS])){
              break;
            }
          }
          //Nao encontrou em nenhum grupo
          if ($j==$numGrupos){
            $str = $this->montarCriterio($objInfraDTO,$arrCriterios[$i]);
            if ($str!=''){
              $strCriterios .= $strSeparador.$str;
              $strSeparador = ' AND ';
            }
            $this->arrCriteriosProcessados[] = $i;
          }
        }
      }
    }

    //ADICIONA GRUPOS DE CRITERIOS
    for($i=0;$i<$numGrupos;$i++){
      if (!in_array($i,$this->arrGruposProcessados)){

        //Verifica se cada um dos crit�rios possui somente as tabelas informadas (processando LEFT JOIN ... ON ...)
        //descartando os crit�rios que possuem apenas atributos da tabela principal
        for ($j=0;$j<count($arrGrupos[$i][InfraDTO::$POS_GRUPO_CRITERIO_CRITERIOS]);$j++){
          for($k=0;$k<$numCriterios;$k++){
            if ($arrCriterios[$k][InfraDTO::$POS_CRITERIO_NOME]==$arrGrupos[$i][InfraDTO::$POS_GRUPO_CRITERIO_CRITERIOS][$j]){
              if (!$this->verificarTabelasCriterios($objInfraDTO,$arrCriterios[$k],$arrTabelas)){
                break 2;
              }
            }
          }
        }

        //Se os crit�rios possuem as tabelas
        if ($j==count($arrGrupos[$i][InfraDTO::$POS_GRUPO_CRITERIO_CRITERIOS])){
          $strCriterios .= $strSeparador.'(';
          //Para cada crit�rio do grupo
          for ($j=0;$j<count($arrGrupos[$i][InfraDTO::$POS_GRUPO_CRITERIO_CRITERIOS]);$j++){
            if ($j>0){
              //coloca operador entre os criterios
              $strCriterios .= ' '.$arrGrupos[$i][InfraDTO::$POS_GRUPO_CRITERIO_OPERADORES_LOGICOS][$j-1].' ';
            }
            //localizar pelo nome o criterio do grupo no array de criterios e ap�s montar
            for($k=0;$k<$numCriterios;$k++){
              if ($arrCriterios[$k][InfraDTO::$POS_CRITERIO_NOME]==$arrGrupos[$i][InfraDTO::$POS_GRUPO_CRITERIO_CRITERIOS][$j]){
                $strCriterios .= $this->montarCriterio($objInfraDTO,$arrCriterios[$k]);
              }
            }
          }
          $strCriterios .= ')';
          $strSeparador = ' AND ';
          $this->arrGruposProcessados[] = $i;
        }
      }
    }

    //InfraDebug::getInstance()->gravar('@'.$strCriterios);
    return $strCriterios;
  }

  private function montarCriterio($objInfraDTO, $arrCriterio){
    $arrAtributos = $objInfraDTO->getArrAtributos();
    $strCriterio = '(';
    for($j=0;$j<count($arrCriterio[InfraDTO::$POS_CRITERIO_ATRIBUTOS]);$j++){
      if ($j>0){
        $strCriterio .= ' '.$arrCriterio[InfraDTO::$POS_CRITERIO_OPERADORES_LOGICOS][$j-1].' ';
      }
      $strCriterio .= $this->montarCondicao($objInfraDTO,$arrAtributos[$arrCriterio[InfraDTO::$POS_CRITERIO_ATRIBUTOS][$j]],$arrCriterio[InfraDTO::$POS_CRITERIO_OPERADORES_ATRIBUTOS][$j],$arrCriterio[InfraDTO::$POS_CRITERIO_VALORES_ATRIBUTOS][$j]);
    }
    $strCriterio .= ')';
    return $strCriterio;
  }

  private function verificarTabelasCriterios($objInfraDTO,$arrCriterio,$arrTabelas){
    //Se n�o tem tabelas para verificacao
    if (!is_array($arrTabelas)){
      return true;
    }
    $arrAtributos = $objInfraDTO->getArrAtributos();
    $arrTabelasCriterio = array();
    //Para cada um dos atributos deste crit�rio
    for($i=0;$i<count($arrCriterio[InfraDTO::$POS_CRITERIO_ATRIBUTOS]);$i++){
      //Obtem tabela do atributo
      $strTabela = $arrAtributos[$arrCriterio[InfraDTO::$POS_CRITERIO_ATRIBUTOS][$i]][InfraDTO::$POS_ATRIBUTO_TAB_ORIGEM];
      if ($strTabela==null){
        $strTabela = $objInfraDTO->getStrNomeTabela();
      }
      //Se a tabela deste atributo n�o esta no array
      if (!in_array($strTabela, $arrTabelas)){
        return false;
      }
      if (!in_array($strTabela,$arrTabelasCriterio)){
        $arrTabelasCriterio[] = $strTabela;
      }
    }

    //Se os crit�rios s�o apenas da tabela principal ent�o deixa pra montar no WHERE
    //provocam efeitos colaterais quando usados em um LEFT JOIN
    if (count($arrTabelasCriterio)==1){

      if ($arrTabelasCriterio[0]==$objInfraDTO->getStrNomeTabela()){
        return false;
      }

      //Se o crit�rio envolve apenas a primeira tabela do relacionamento deixa para montar
      //no pr�ximo ON ou ent�o no WHERE
      if (count($arrTabelas)==2 && $arrTabelasCriterio[0]==$arrTabelas[0]){
        return false;
      }

    }

    return true;
  }

  protected function montarOrderBy($objInfraDTO) {
    $strRet = '';
    $strSeparador = '';

    $arrOrdenacao = $objInfraDTO->getArrOrdenacao();
    if (is_array($arrOrdenacao)){
      $arrAtributos = $objInfraDTO->getArrAtributos();
      foreach($arrOrdenacao as $atributoOrd){
        $atributo = $arrAtributos[$atributoOrd[0]];
        if ($atributo[InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_ORD){
          if($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null){
            $strRet .= $strSeparador;
            $strRet .= $this->montarPrefixoCampo($objInfraDTO, $atributo);
            $strRet .= $atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].' '.$atributoOrd[1];
            //$strRet .= $this->arrAlias[$atributo[InfraDTO::$POS_ATRIBUTO_NOME]].' '.$atributoOrd[1];
            $strSeparador = ', ';
          }
        }
      }
      if ( $strRet != '' ) {
        $strRet = ' ORDER BY '.$strRet;
      }
    }
    return $strRet;
  }

  protected function gerarAlias($objInfraDTO){
    $arrAtributos = $objInfraDTO->getArrAtributos();
    $this->arrAlias = array();
    $i = 1;
    foreach($arrAtributos as $atributo){
      //usar sempre em minusculas (Ingres sempre retorna minusculo)
      if ($this->getObjInfraIBanco() instanceof InfraMumps){
        //usa o nome do campo porque o mumps nao trata alias
        $this->arrAlias[$atributo[InfraDTO::$POS_ATRIBUTO_NOME]] = strtolower($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]);
      } else {

        $strAlias = strtolower($atributo[InfraDTO::$POS_ATRIBUTO_NOME]);

        //limitar em 30 porque o sql server retorna vazio se for maior que isso
        if (strlen($strAlias)<=30){
          $this->arrAlias[$atributo[InfraDTO::$POS_ATRIBUTO_NOME]] = $strAlias;
        }else{
          $this->arrAlias[$atributo[InfraDTO::$POS_ATRIBUTO_NOME]] = substr($strAlias,0,27).str_pad($i,3,'0',STR_PAD_LEFT);
          $i++;
        }
      }
    }
  }


  protected function montarDTORetorno($objInfraDTO, $rsItem){
    $reflectionClass = new ReflectionClass(get_class($objInfraDTO));
    $objRet = $reflectionClass->newInstance();

    $arrAtributosRet = array();
    $arrAtributos = $objInfraDTO->getArrAtributos();
    $arrKeys = array_keys($arrAtributos);
    foreach($arrKeys as $key){
      if ( $arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]!==null){
        if ( $arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_FLAGS] & InfraDTO::$FLAG_RET){
          $valor = $this->lerCampo($arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO],$rsItem[$this->arrAlias[$key]]);
          $arrAtributosRet[$key][InfraDTO::$POS_ATRIBUTO_VALOR]=$valor;
          $arrAtributosRet[$key][InfraDTO::$POS_ATRIBUTO_FLAGS] = InfraDTO::$FLAG_SET | InfraDTO::$FLAG_IGUAL;
          //call_user_func(array($objRet,'set'.$arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO].$key),$valor);
        }
      }
    }
    //Adiciona atributos diretamente economizando chamadas de metodos
    $objRet->setArrAtributos($arrAtributosRet);
    return $objRet;
  }


  protected function montarWherePK($objInfraDTO) {
    $strRet = '';
    $strSeparador = '';

    $arrAtributos = $objInfraDTO->getArrAtributos();
    $arrPK = $objInfraDTO->getArrPK();

    if ($arrPK!=null){
      $arrKeys = array_keys($arrPK);
      foreach($arrKeys as $key){
        //testar prefixo da pk
        $valor = call_user_func(array($objInfraDTO,'get'.$arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO].$key));
        $strRet .= $strSeparador.$this->montarPrefixoCampo($objInfraDTO,$arrAtributos[$key]).$arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_CAMPO_SQL].'='.$this->gravarCampo($arrAtributos[$key][InfraDTO::$POS_ATRIBUTO_PREFIXO],$valor);
        $strSeparador = ' AND ';
      }
    }

    if ( $strRet != '' ) {
      $strRet = ' WHERE '.$strRet;
    } else {
      throw new InfraException('Erro montando condi��o de chave-prim�ria para tabela '.$objInfraDTO->getStrNomeTabela().'.');
    }
    return $strRet;
  }

  private function selecionarCampo($objInfraDTO, $atributo){


    $strTabela = $this->obterPrefixoCampo($objInfraDTO,$atributo);
    $strCampo = strtolower($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL]);
    $strAlias = $this->arrAlias[$atributo[InfraDTO::$POS_ATRIBUTO_NOME]];

    //Se o alias tem o mesmo nome do campo ent�o � desnecess�rio
    if ($strAlias == strtolower($atributo[InfraDTO::$POS_ATRIBUTO_CAMPO_SQL])){
      $strAlias = null;
    }

    $strPrefixo = $atributo[InfraDTO::$POS_ATRIBUTO_PREFIXO];

    if ($strPrefixo == InfraDTO::$PREFIXO_NUM){
      return $this->getObjInfraIBanco()->formatarSelecaoNum($strTabela, $strCampo, $strAlias);
    } else if($strPrefixo == InfraDTO::$PREFIXO_STR){
      return $this->getObjInfraIBanco()->formatarSelecaoStr($strTabela, $strCampo, $strAlias);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DTA){
      return $this->getObjInfraIBanco()->formatarSelecaoDta($strTabela, $strCampo, $strAlias);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DTH){
      return $this->getObjInfraIBanco()->formatarSelecaoDth($strTabela, $strCampo, $strAlias);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_BOL){
      return $this->getObjInfraIBanco()->formatarSelecaoBol($strTabela, $strCampo, $strAlias);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DIN){
      return $this->getObjInfraIBanco()->formatarSelecaoDin($strTabela, $strCampo, $strAlias);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DBL){
      return $this->getObjInfraIBanco()->formatarSelecaoDbl($strTabela, $strCampo, $strAlias);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_BIN){
      return $this->getObjInfraIBanco()->formatarSelecaoBin($strTabela, $strCampo, $strAlias);
    } else {
      throw new InfraException('Prefixo ['.$strPrefixo.'] inv�lido selecionando campo.');
    }

    return null;
  }

  private function gravarCampo($strPrefixo, $valor){

    if ($valor===null){
      return 'NULL';
    }

    if ($strPrefixo == InfraDTO::$PREFIXO_NUM){
      return $this->getObjInfraIBanco()->formatarGravacaoNum($valor);
    } else if($strPrefixo == InfraDTO::$PREFIXO_STR){
      return $this->getObjInfraIBanco()->formatarGravacaoStr($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DTA){
      return $this->getObjInfraIBanco()->formatarGravacaoDta($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DTH){
      return $this->getObjInfraIBanco()->formatarGravacaoDth($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_BOL){
      return $this->getObjInfraIBanco()->formatarGravacaoBol($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DIN){
      return $this->getObjInfraIBanco()->formatarGravacaoDin($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DBL){
      return $this->getObjInfraIBanco()->formatarGravacaoDbl($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_BIN){
      return $this->getObjInfraIBanco()->formatarGravacaoBin($valor);
    } else {
      throw new InfraException('Prefixo ['.$strPrefixo.'] inv�lido gravando campo.');
    }

    return null;
  }

  private function lerCampo($strPrefixo, $valor){

    if ($valor===null){
      return null;
    }

    if ($strPrefixo == InfraDTO::$PREFIXO_NUM){
      return $this->getObjInfraIBanco()->formatarLeituraNum($valor);
    } else if($strPrefixo == InfraDTO::$PREFIXO_STR){
      return $this->getObjInfraIBanco()->formatarLeituraStr($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DTA){
      return $this->getObjInfraIBanco()->formatarLeituraDta($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DTH){
      return $this->getObjInfraIBanco()->formatarLeituraDth($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_BOL){
      return $this->getObjInfraIBanco()->formatarLeituraBol($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DIN){
      return $this->getObjInfraIBanco()->formatarLeituraDin($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_DBL){
      return $this->getObjInfraIBanco()->formatarLeituraDbl($valor);
    } else if ($strPrefixo == InfraDTO::$PREFIXO_BIN){
      return $this->getObjInfraIBanco()->formatarLeituraBin($valor);
    } else {
      throw new InfraException('Prefixo \''.$strPrefixo.'\' inv�lido lendo campo.');
    }

    return null;
  }

}
?>