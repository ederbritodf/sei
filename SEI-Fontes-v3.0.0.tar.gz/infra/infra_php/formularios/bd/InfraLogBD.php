<?
/**
* TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
*
* 02/05/2008 - criado por mga
*
* Vers�o do Gerador de C�digo: 1.16.0
*
* Vers�o no CVS: $Id$
*/

//require_once 'Infra.php';

class InfraLogBD extends InfraBD {

  public function __construct(InfraIBanco $objInfraIBanco){
    parent::__construct($objInfraIBanco);
  }

}
?>