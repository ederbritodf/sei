<?
/**
* TRIBUNAL REGIONAL FEDERAL DA 4� REGI�O
*
* 15/12/2011 - criado por tamir_db
*
* Vers�o do Gerador de C�digo: 1.32.1
*
* Vers�o no CVS: $Id$
*/

//require_once dirname(__FILE__).'/../Infra.php';

class InfraAgendamentoTarefaRN extends InfraRN {

  //public static $PERIODICIDADEEXECUCAO_HORA = 'H';
  public static $PERIODICIDADEEXECUCAO_DIA = 'D';
  public static $PERIODICIDADEEXECUCAO_SEMANA = 'S';
  public static $PERIODICIDADEEXECUCAO_MES = 'M';
  public static $PERIODICIDADEEXECUCAO_ANO = 'A';
  

  public function __construct(){
    parent::__construct();
  }

  protected function inicializarObjInfraIBanco(){
    return BancoInfra::getInstance();
  }

  public function listarValoresPeriodicidadeExecucao(){
    try {

      $objArrInfraAgendamentoPeriodicidadeDTO = array();

      /*$objInfraAgendamentoPeriodicidadeDTO = new InfraAgendamentoPeriodicidadeDTO();
      $objInfraAgendamentoPeriodicidadeDTO->setStrStaPeriodicidadeExecucao(self::$PERIODICIDADEEXECUCAO_HORA);
      $objInfraAgendamentoPeriodicidadeDTO->setStrDescricao('Hora');
      $objArrInfraAgendamentoPeriodicidadeDTO[] = $objInfraAgendamentoPeriodicidadeDTO;*/

      $objInfraAgendamentoPeriodicidadeDTO = new InfraAgendamentoPeriodicidadeDTO();
      $objInfraAgendamentoPeriodicidadeDTO->setStrStaPeriodicidadeExecucao(self::$PERIODICIDADEEXECUCAO_DIA);
      $objInfraAgendamentoPeriodicidadeDTO->setStrDescricao('Di�rio');
      $objArrInfraAgendamentoPeriodicidadeDTO[] = $objInfraAgendamentoPeriodicidadeDTO;

      $objInfraAgendamentoPeriodicidadeDTO = new InfraAgendamentoPeriodicidadeDTO();
      $objInfraAgendamentoPeriodicidadeDTO->setStrStaPeriodicidadeExecucao(self::$PERIODICIDADEEXECUCAO_SEMANA);
      $objInfraAgendamentoPeriodicidadeDTO->setStrDescricao('Semanal');
      $objArrInfraAgendamentoPeriodicidadeDTO[] = $objInfraAgendamentoPeriodicidadeDTO;
      
     	$objInfraAgendamentoPeriodicidadeDTO = new InfraAgendamentoPeriodicidadeDTO();
      $objInfraAgendamentoPeriodicidadeDTO->setStrStaPeriodicidadeExecucao(self::$PERIODICIDADEEXECUCAO_MES);
      $objInfraAgendamentoPeriodicidadeDTO->setStrDescricao('Mensal');
      $objArrInfraAgendamentoPeriodicidadeDTO[] = $objInfraAgendamentoPeriodicidadeDTO;
      
     	$objInfraAgendamentoPeriodicidadeDTO = new InfraAgendamentoPeriodicidadeDTO();
      $objInfraAgendamentoPeriodicidadeDTO->setStrStaPeriodicidadeExecucao(self::$PERIODICIDADEEXECUCAO_ANO);
      $objInfraAgendamentoPeriodicidadeDTO->setStrDescricao('Anual');
      $objArrInfraAgendamentoPeriodicidadeDTO[] = $objInfraAgendamentoPeriodicidadeDTO;

      return $objArrInfraAgendamentoPeriodicidadeDTO;

    }catch(Exception $e){
      throw new InfraException('Erro listando valores de Periodicidade da Execu��o.',$e);
    }
  }

  private function validarStrDescricao(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrDescricao())){
      $objInfraException->adicionarValidacao('Descri��o n�o informada.');
    }else{
      $objInfraAgendamentoTarefaDTO->setStrDescricao(trim($objInfraAgendamentoTarefaDTO->getStrDescricao()));

      if (strlen($objInfraAgendamentoTarefaDTO->getStrDescricao())>500){
        $objInfraException->adicionarValidacao('Descri��o possui tamanho superior a 500 caracteres.');
      }
    }
  }

  private function validarStrComando(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrComando())){
      $objInfraException->adicionarValidacao('Comando n�o informado.');
    }else{
      $objInfraAgendamentoTarefaDTO->setStrComando(trim($objInfraAgendamentoTarefaDTO->getStrComando()));

      if (strlen($objInfraAgendamentoTarefaDTO->getStrComando())>255){
        $objInfraException->adicionarValidacao('Comando possui tamanho superior a 255 caracteres.');
      }
    }
  }

  private function validarStrSinAtivo(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrSinAtivo())){
      $objInfraException->adicionarValidacao('Sinalizador de Exclus�o L�gica n�o informado.');
    }else{
      if (!InfraUtil::isBolSinalizadorValido($objInfraAgendamentoTarefaDTO->getStrSinAtivo())){
        $objInfraException->adicionarValidacao('Sinalizador de Exclus�o L�gica inv�lido.');
      }
    }
  }

  private function validarStrStaPeriodicidadeExecucao(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrStaPeriodicidadeExecucao())){
      $objInfraException->adicionarValidacao('Periodicidade de Execu��o n�o informada.');
    }else{
      if (!in_array($objInfraAgendamentoTarefaDTO->getStrStaPeriodicidadeExecucao(),InfraArray::converterArrInfraDTO($this->listarValoresPeriodicidadeExecucao(),'StaPeriodicidadeExecucao'))){
        $objInfraException->adicionarValidacao('Periodicidade de Execu��o inv�lida.');
      }
    }
  }

  private function validarStrPeriodicidadeComplemento(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrPeriodicidadeComplemento())){
      $objInfraException->adicionarValidacao('Complemento da Periodicidade n�o informado.');
    }else{
      $objInfraAgendamentoTarefaDTO->setStrPeriodicidadeComplemento(trim($objInfraAgendamentoTarefaDTO->getStrPeriodicidadeComplemento()));

      if (strlen($objInfraAgendamentoTarefaDTO->getStrPeriodicidadeComplemento())>100){
        $objInfraException->adicionarValidacao('Complemento da Periodicidade possui tamanho superior a 100 caracteres.');
      }
    }
  }

  private function validarDthUltimaExecucao(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getDthUltimaExecucao())){
    	$objInfraAgendamentoTarefaDTO->setDthUltimaExecucao(null);
    }
  }

  private function validarDthUltimaConclusao(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getDthUltimaConclusao())){
    	$objInfraAgendamentoTarefaDTO->setDthUltimaConclusao(null);
    }
  }

  private function validarStrParametro(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrParametro())){
      $objInfraAgendamentoTarefaDTO->setStrParametro(null);
    }else{
      $objInfraAgendamentoTarefaDTO->setStrParametro(trim($objInfraAgendamentoTarefaDTO->getStrParametro()));

      if (strlen($objInfraAgendamentoTarefaDTO->getStrParametro())>250){
        $objInfraException->adicionarValidacao('Parametro possui tamanho superior a 250 caracteres.');
      }
    }
  }

  private function validarStrEmailErro(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrEmailErro())){
      $objInfraAgendamentoTarefaDTO->setStrEmailErro(null);
    }else{
      $objInfraAgendamentoTarefaDTO->setStrEmailErro(trim($objInfraAgendamentoTarefaDTO->getStrEmailErro()));

      if (strlen($objInfraAgendamentoTarefaDTO->getStrEmailErro())>250){
        $objInfraException->adicionarValidacao('Email de Erro possui tamanho superior a 250 caracteres.');
      }

      $arr = explode(';',$objInfraAgendamentoTarefaDTO->getStrEmailErro());

      $numDestinatarios = count($arr);

      for ($i = 0; $i < $numDestinatarios; $i++) {
        if ($arr[$i] != '') {
          if (!InfraUtil::validarEmail($arr[$i])) {
            $objInfraException->adicionarValidacao('E-mail de erro "' . $arr[$i] . '" inv�lido.');
          }
        }
      }
    }
  }

  private function validarStrSinSucesso(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getStrSinSucesso())){
      $objInfraException->adicionarValidacao('Sinalizador de Sucesso da Execu��o n�o informado.');
    }else{
      if (!InfraUtil::isBolSinalizadorValido($objInfraAgendamentoTarefaDTO->getStrSinSucesso())){
        $objInfraException->adicionarValidacao('Sinalizador de Sucesso da Execu��o inv�lido.');
      }
    }
  }

  /*private function validarNumIdOrgao(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO, InfraException $objInfraException){
    if (InfraString::isBolVazia($objInfraAgendamentoTarefaDTO->getNumIdOrgao())){
      $objInfraException->adicionarValidacao('Org�o n�o informado.');
    }
  }*/

  protected function cadastrarControlado(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO) {
    try{

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_cadastrar');

      //Regras de Negocio
      $objInfraException = new InfraException();

      $this->validarStrDescricao($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrComando($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrSinAtivo($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrStaPeriodicidadeExecucao($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrPeriodicidadeComplemento($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrParametro($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarDthUltimaExecucao($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarDthUltimaConclusao($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrSinSucesso($objInfraAgendamentoTarefaDTO, $objInfraException);
      $this->validarStrEmailErro($objInfraAgendamentoTarefaDTO, $objInfraException);
      //$this->validarNumIdOrgao($objInfraAgendamentoTarefaDTO, $objInfraException);

      $objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      $ret = $objInfraAgendamentoTarefaBD->cadastrar($objInfraAgendamentoTarefaDTO);

      //Auditoria

      return $ret;

    }catch(Exception $e){
      throw new InfraException('Erro cadastrando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function alterarControlado(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
  	   SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_alterar');

      //Regras de Negocio
      $objInfraException = new InfraException();

      if ($objInfraAgendamentoTarefaDTO->isSetStrDescricao()){
        $this->validarStrDescricao($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrComando()){
        $this->validarStrComando($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrSinAtivo()){
        $this->validarStrSinAtivo($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrStaPeriodicidadeExecucao()){
        $this->validarStrStaPeriodicidadeExecucao($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrPeriodicidadeComplemento()){
        $this->validarStrPeriodicidadeComplemento($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrParametro()){
      	$this->validarStrParametro($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetDthUltimaExecucao()){
        $this->validarDthUltimaExecucao($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetDthUltimaConclusao()){
        $this->validarDthUltimaConclusao($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrSinSucesso()){
        $this->validarStrSinSucesso($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      if ($objInfraAgendamentoTarefaDTO->isSetStrEmailErro()){
      	$this->validarStrEmailErro($objInfraAgendamentoTarefaDTO, $objInfraException);
      }
      /*if ($objInfraAgendamentoTarefaDTO->isSetNumIdOrgao()){
        $this->validarNumIdOrgao($objInfraAgendamentoTarefaDTO, $objInfraException);
      }*/

      $objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      $objInfraAgendamentoTarefaBD->alterar($objInfraAgendamentoTarefaDTO);

      //Auditoria

    }catch(Exception $e){
      throw new InfraException('Erro alterando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function excluirControlado($arrObjInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_excluir');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      for($i=0;$i<count($arrObjInfraAgendamentoTarefaDTO);$i++){
        $objInfraAgendamentoTarefaBD->excluir($arrObjInfraAgendamentoTarefaDTO[$i]);
      }

      //Auditoria

    }catch(Exception $e){
      throw new InfraException('Erro excluindo InfraAgendamentoTarefa.',$e);
    }
  }

  protected function consultarConectado(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_consultar');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      $ret = $objInfraAgendamentoTarefaBD->consultar($objInfraAgendamentoTarefaDTO);

      //Auditoria

      return $ret;
    }catch(Exception $e){
      throw new InfraException('Erro consultando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function listarConectado(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO) {
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_listar');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      $ret = $objInfraAgendamentoTarefaBD->listar($objInfraAgendamentoTarefaDTO);

      //Auditoria

      return $ret;

    }catch(Exception $e){
      throw new InfraException('Erro listando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function contarConectado(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_listar');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      $ret = $objInfraAgendamentoTarefaBD->contar($objInfraAgendamentoTarefaDTO);

      //Auditoria

      return $ret;
    }catch(Exception $e){
      throw new InfraException('Erro contando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function desativarControlado($arrObjInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_desativar');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      for($i=0;$i<count($arrObjInfraAgendamentoTarefaDTO);$i++){
        $objInfraAgendamentoTarefaBD->desativar($arrObjInfraAgendamentoTarefaDTO[$i]);
      }

      //Auditoria

    }catch(Exception $e){
      throw new InfraException('Erro desativando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function reativarControlado($arrObjInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_reativar');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      for($i=0;$i<count($arrObjInfraAgendamentoTarefaDTO);$i++){
        $objInfraAgendamentoTarefaBD->reativar($arrObjInfraAgendamentoTarefaDTO[$i]);
      }

      //Auditoria

    }catch(Exception $e){
      throw new InfraException('Erro reativando InfraAgendamentoTarefa.',$e);
    }
  }

  protected function bloquearControlado(InfraAgendamentoTarefaDTO $objInfraAgendamentoTarefaDTO){
    try {

      //Valida Permissao
      SessaoInfra::getInstance()->validarPermissao('infra_agendamento_tarefa_consultar');

      //Regras de Negocio
      //$objInfraException = new InfraException();

      //$objInfraException->lancarValidacoes();

      $objInfraAgendamentoTarefaBD = new InfraAgendamentoTarefaBD($this->getObjInfraIBanco());
      $ret = $objInfraAgendamentoTarefaBD->bloquear($objInfraAgendamentoTarefaDTO);

      //Auditoria

      return $ret;
    }catch(Exception $e){
      throw new InfraException('Erro bloqueando InfraAgendamentoTarefa.',$e);
    }
  }
}
?>